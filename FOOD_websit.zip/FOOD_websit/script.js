document.addEventListener('DOMContentLoaded', () => {
    const checkBox = document.getElementById('check');
    const menuIcon = document.getElementById('menu-icon');
    const closeIcon = document.getElementById('close-icon');
    const navbar = document.querySelector('.navbar');
    const navLinks = document.querySelectorAll('.navbar a');
    const sections = document.querySelectorAll('section');

    // Smooth toggling of the menu
    checkBox.addEventListener('change', () => {
        if (checkBox.checked) {
            navbar.style.height = '17.7rem'; // Expand navbar
            navbar.style.opacity = '1';      // Smooth opacity transition
            menuIcon.style.display = 'none';
            closeIcon.style.display = 'block';
        } else {
            navbar.style.height = '0';       // Collapse navbar
            navbar.style.opacity = '0';      // Smooth opacity transition
            menuIcon.style.display = 'block';
            closeIcon.style.display = 'none';
        }
    });

    // Add hover effect to navbar links for a glowing effect
    navLinks.forEach(link => {
        link.addEventListener('mouseover', () => {
            link.style.textShadow = '0 0 8px rgba(255, 255, 255, 0.8)';
            link.style.transform = 'scale(1.1)'; // Slightly enlarge on hover
            link.style.transition = 'all 0.3s ease';
        });

        link.addEventListener('mouseout', () => {
            link.style.textShadow = 'none';
            link.style.transform = 'scale(1)';
        });

        // Add functionality to show the corresponding section when a link is clicked
        link.addEventListener('click', (e) => {
            e.preventDefault(); // Prevent default link behavior
            const targetId = link.getAttribute('href').substring(1); // Get the section id

            // Hide all sections
            sections.forEach(section => {
                section.classList.remove('active');
                section.style.display = 'none';
                section.style.opacity = '0';
                section.style.transform = 'translateY(20px)';
            });

            // Show the clicked section
            const targetSection = document.getElementById(targetId);
            targetSection.classList.add('active');
            targetSection.style.display = 'block';
            targetSection.style.opacity = '1';
            targetSection.style.transform = 'translateY(0)';

            // Optionally, close the navbar on mobile when a link is clicked
            checkBox.checked = false;
            navbar.style.height = '0';
            navbar.style.opacity = '0';
            menuIcon.style.display = 'block';
            closeIcon.style.display = 'none';
        });
    });

    // Set the first section as active by default
    document.getElementById('home').classList.add('active');
    document.getElementById('home').style.display = 'block';
    document.getElementById('home').style.opacity = '1';
    document.getElementById('home').style.transform = 'translateY(0)';
});
